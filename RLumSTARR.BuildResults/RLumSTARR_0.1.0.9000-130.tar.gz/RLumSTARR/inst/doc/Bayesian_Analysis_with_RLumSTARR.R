## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center"
)
library(RLumSTARR)

## -----------------------------------------------------------------------------
files <-
  list.files(system.file("extdata", "", package = "RLumSTARR"), full.names =
               TRUE)

## ---- fig.width = 8-----------------------------------------------------------
## create curve array 
dat <- create_RFCurveArray(files = files)
plot(dat)

## -----------------------------------------------------------------------------
##run modelling for one ROI
output <- extract_TRUELight(
 data = dat,
 ROI = c(5),
 stepping = 80,
 verbose = FALSE,
 method_control = list(
   n.chain = 3,
   n.iter = 50000,
   variable.names = c("mu", "phi", "omega", "epsilon"),
   thin = 20))

## -----------------------------------------------------------------------------
summary(output$jags_output)

## ---- fig.width = 6, fig.height = 10------------------------------------------
plot(output$jags_output)

