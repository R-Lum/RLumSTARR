library(testthat)
library(RLumSTARR)

test_check("RLumSTARR")
